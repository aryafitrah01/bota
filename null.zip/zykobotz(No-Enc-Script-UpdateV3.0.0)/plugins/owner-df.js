let fs = require('fs');
let path = require('path');

let handler = async (m, { text, usedPrefix, command }) => {
    if (!text) throw `Untuk menghapus file atau folder, gunakan format:\n\nHapus dalam! Plugis ketik ${usedPrefix + command} <namafile>\nHapus luar plugis ketik ${usedPrefix + command} <folder/namafile>\n\nContoh:\nHapus dalam! Plugis ketik ${usedPrefix + command} menu\nHapus luar plugis ketik ${usedPrefix + command} html/anjay.json\n\nBY : zeyybotz`;
    if (text.includes('/')) {
        let [folder, file] = text.split('/');
        let filePath = path.resolve(`${folder}/${file}`);
        let isDirectory = fs.statSync(filePath).isDirectory();
        if (fs.existsSync(filePath)) {
            if (isDirectory) {
                fs.rmdirSync(filePath, { recursive: true });
                m.reply(`Folder ${folder}/${file} berhasil dihapus`);
            } else {
                fs.unlinkSync(filePath);
                m.reply(`File ${file} di folder ${folder} berhasil dihapus`);
            }
        } else {
            throw `File atau folder ${text} tidak ditemukan`;
        }
    } else {
        let filePath = path.resolve(`plugins/${text}.js`);
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
            m.reply(`File ${text}.js di dalam folder plugins berhasil dihapus`);
        } else {
            throw `File ${text}.js di dalam folder plugins tidak ditemukan`;
        }
    }
}

handler.help = ['df'].map(v => v + ' <folder/namafile>');
handler.tags = ['owner'];
handler.command = /^(df)$/i;
handler.rowner = true;

module.exports = handler;
