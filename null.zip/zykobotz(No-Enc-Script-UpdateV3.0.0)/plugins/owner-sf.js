let { spawn } = require('child_process')
let ffmpeg = require('fluent-ffmpeg')
let fs = require('fs')
let path = require('path')
let { MessageType } = require('@adiwajshing/baileys')
let handler = async (m, { text, usedPrefix, command }) => {
switch (command) { 
case 'sf': {
if (!text) throw `*_LIST SF_*



° sf : menyimpan file dalam plugins/luar plugins 
° sf2 : menyimpan file dengan nama file saja
° sfimg : menyimpan folder Poto
° sfvnmp3 : menyimpan folder audio/vn
° sfvidmp4 : menyimpan folder vidio

📮 NOTE : buat folder ketik .addfolder

BY : zeyybotz`
    if (!m.quoted.text) throw `reply code`
    
    let filePath = text;
    if (!filePath.startsWith('/')) {
        filePath = path.join(__dirname, '..', filePath);
    }
    
    await require('fs').writeFileSync(filePath, m.quoted.text)

    m.reply(`Save ${filePath}`)
}
break
case 'sf2': {
    if (!text) throw `Dimana letak path nya?\n\nContoh:\n${usedPrefix + command} plugins/menu.js`

    let filePath = text;
    await require('fs').writeFileSync(filePath, '');
    m.reply(`Berhasil menyimpan file di ${filePath}`);
}
break 
case 'sfimg': {
let image = m.quoted && m.quoted.mimetype.startsWith('image') ? await m.quoted.download() : m.msg.imageData
        if (!image) return conn.reply(m.chat, `🚩 Kirim/Reply gambar dengan keterangan *${usedPrefix+command}* folder|NamaGambar|pilihan png\n\nContoh: ${usedPrefix+command} media|zeyybotz|png\n\nfitur ini adalah untuk add gambar kepada folder media di dalam script ini jadi folder media yang telah add gambar maka image yang add bisa gunakan dengan ganti Poto dan sebagai nya\n\n by: zeyybotz`, m)
        let [name1, name2, name3] = text.split`|`
        if (!name1) return conn.reply(m.chat, 'Masukkan nama folder nya', m)
        if (!name2) return conn.reply(m.chat, 'Masukkan Nama!', m) 
        let ext = path.extname(name1, name2)
        let namabaru = name2.replace(ext, '') + `.${name3}`
        let filepath = path.join(__dirname, `../${name1}/`, namabaru)
        if (fs.existsSync(filepath)) {
          return conn.reply(m.chat, `File *${namabaru}* telah digunakan. Silakan cari nama yang lain.`, m)
        }
        fs.writeFileSync(filepath, image)
        conn.reply(m.chat, `🚩 Berhasil menyimpan *${namabaru}*\nke folder ${name1}`, m)
      }
      break
      case 'sfvnmp3': {
  let vn = m.quoted && m.quoted.mimetype.startsWith('audio') ? await m.quoted.download() : m.msg.audioData
  if (!vn) return conn.reply(m.chat, `🚩 Send/Reply Song with the caption *${usedPrefix+command}* folder/Nama Audio/pilihan opus\n\nContoh: ${usedPrefix+command} mp3/zeyybotz/opus\n\nfitur ini adalah untuk add audio kepada folder di dalam script ini\n\n by: zeyybotz`, m)
  let [name1, name2, name3] = text.split`/`
  if (!name1) return conn.reply(m.chat, 'Masukkan nama folder nya', m)
  if (!name2) return conn.reply(m.chat, 'Masukkan Nama!', m)         
  if (!name3) return conn.reply(m.chat, 'Enter mp3 atau opus!', m)
  let ext = path.extname(name1, name2)
  let namabaru = name2.replace(ext, '') + `.${name3}`
  let filepath = path.join(__dirname, `../${name1}/`, namabaru)
  if (fs.existsSync(filepath)) {
    return conn.reply(m.chat, `File *${namabaru}* telah di gunakan. Silahkan cari nama yang lain.`, m)
  }
 conn.sendMessage(m.chat, { react: { text: "🕒", key: m.key } });
  let bufs = []
  let cmd = spawn('ffmpeg', [
    '-i', '-',
    '-f', 'opus',
    '-ar', '48000',
    '-ac', '2',
    '-vbr', 'on',
    '-application', 'voip',
    '-compression_level', '10',
    '-frame_duration', '20',
    '-packet_loss', '5',
    'pipe:1'
  ])
  cmd.stderr.on('data', console.error)
  cmd.stdout.on('data', chunk => bufs.push(chunk))
  cmd.on('exit', async code => {
    if (code !== 0) return conn.reply(m.chat, `🚩 Gagal menambahkan *${name2}*.${name3}`, m)

    let buffer = Buffer.concat(bufs)
    await fs.promises.writeFile(filepath, buffer)

    conn.reply(m.chat, `🚩 Berhasil menyimpan *${namabaru}*\nke folder ${name1}`, m)
  })
  cmd.stdin.write(vn)
  cmd.stdin.end()
}
break      
case 'sfvidmp4': {
  let vid = m.quoted && m.quoted.mimetype.startsWith('video') ? await m.quoted.download() : m.msg.videoData
  if (!vid) return conn.reply(m.chat, `🚩 Send/Reply Vidio caption *${usedPrefix+command}* folder/Nama vidoe/pilihan mp4\n\nContoh: ${usedPrefix+command} mp4/zeyybotz/mp4\n\nfitur ini adalah untuk add video kepada folder di dalam script ini\n\n by: zeyybotz`, m)
  let [name1, name2, name3] = text.split`/`
  if (!name1) return conn.reply(m.chat, 'Masukkan nama folder nya', m)
  if (!name2) return conn.reply(m.chat, 'Masukkan Nama!', m)         
  if (!name3) return conn.reply(m.chat, 'Enter mp3 atau opus!', m)
  let ext = path.extname(name1, name2)
  let namabaru = name2.replace(ext, '') + `.${name3}`
  let filepath = path.join(__dirname, `../${name1}/`, namabaru)
  if (fs.existsSync(filepath)) {
    return conn.reply(m.chat, `File *${namabaru}* telah di gunakan. Silahkan cari nama yang lain.`, m)
  }
    await fs.promises.writeFile(filepath, vid)

    conn.reply(m.chat, `🚩 Berhasil menyimpan *${namabaru}*\nke folder ${name1}`, m)
  }
      break;
    }
  
};
handler.help = ['sf', 'sf2', 'sfimg', 'sfvnmp3', 'sfvidmp4',].map(v => v + ' <path>')
handler.tags = ["owner"]
handler.command = /^sf|sf2|sfimg|sfvnmp3|sfvidmp4$/i

handler.owner = true
module.exports = handler