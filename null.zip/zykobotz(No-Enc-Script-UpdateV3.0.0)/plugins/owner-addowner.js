/*


Di Record : Zyko MD
©Zyko MD 2024

 * ig: @zzyko_04
 * yt: @zykobotz
 * tt: @zzyko_04

Jangan di hapus creatornya kack
Saya capek ngetik kode 

"Wahai orang-orang yang beriman, mengapakah kamu mengatakan sesuatu yang tidak kamu kerjakan?
Amat besar kebencian di sisi Allah bahwa kamu mengatakan apa-apa yang tidak kamu kerjakan."
(QS ash-Shaff: 2-3).
*/





let handler = async (m, { conn, text, usedPrefix, command }) => {
	text = (text || '').split('|')
	let who = text[1] ? (text[1].replace(/\D/g, '') + '@s.whatsapp.net') : m.quoted ? m.quoted.sender : (m.mentionedJid && m.mentionedJid[0]) ? m.mentionedJid[0] : ''
	if (!who) return m.reply(`Format : ${usedPrefix + command} nama | @tag/NoHp`)
	let meh = await conn.onWhatsApp(who)
	if (meh.length == 0) return m.reply(`[!] Failed, @${(who.split('@')[0] || '')} bukan pengguna WhatsApp.`, null, { mentions: [who] })
	if (who == conn.user.jid) return m.reply(`[ ! ] Nomor Bot sudah otomatis menjadi owner.`)
	if (global.owner.map(([number]) => number).includes(who.split('@')[0])) return m.reply('[ ! ] Dia sudah jadi owner.')
	if (global.owner.map(([number]) => number).includes(who.split('@')[0])) return m.reply('[ ! ] Dia sudah jadi owner.')
	global.owner.push([who.split('@')[0], text[0], true])
	await conn.reply(m.chat, `Sukses menjadikan @${who.split('@')[0]} sebagai *owner*.`, m, { mentions: [who] })
}
handler.help = ['addowner'].map(v => v + ' <@tag>')
handler.tags = ['owner']
handler.command = /^(add|tambah|\+)owner$/i
handler.owner = true
module.exports = handler



