let handler = async (m, { conn }) => {
	//-----PRICE
//sewa
let sh = '5'
let sn = '10'
let ss = '15'
//premium
let ph = '1'
let pn = '5'
let pp = '10'
let pv = '20'
let info = `
╭━━━━「 *SEWA* 」
┊⫹⫺ *Hemat:* _${sh}k/grup (7 day)_
┊⫹⫺ *Normal:* _${sn}k/grup (15 day)_
┊⫹⫺ *Standar:* _${ss}k/grup (30 day)_
╰═┅═━––––––๑

╭━━━━「 *PREMIUM* 」
┊⫹⫺ *Hemat:* _${ph}k (1 day)_
┊⫹⫺ *Normal:* _${pn}k (7 day)_
┊⫹⫺ *standa:* _${pp}k (15 day)_
┊⫹⫺ *pro:* _${pv}k (30 day)_                    
╰═┅═━––––––๑

*⫹⫺ PAYMENT:*
• *Pulsa Telkomsel:* [${ppulsa}]
• *Dana:* [${pdana}]
• *Gopay:* [${pgopay}]
• *Ovo:* [${povo}]
• *Link Aja:* [${plinkaja}]

–––––– *🐾 Kebijakan* ––––––
🗣️: Kak, Kok harganya mahal banget?
💬: Mau tawar menawar? boleh, silahkan chat owner aja

🗣️: Scam ga nih kak?
💬: Enggalah, Owner 100% Tepati janji #STAYHALAL

▌│█║▌║▌║║▌║▌║█│▌

*example*
*.order text*
`
m.reply(info)
}

handler.help = ['sewa', 'premium']
handler.tags = ['info']
handler.command = /^(sewa(bot)?|premium)$/i
module.exports = handler
