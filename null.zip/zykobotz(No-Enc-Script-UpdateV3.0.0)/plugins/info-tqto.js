let handler = async (m, { conn, args, command }) => {
       let nnn = `@${m.sender.replace(/@.+/, '')}`
       let hj = '0'
       let mek = '6282194564131'
     //  let k = `@${mek.split`@`[0]}`
       let akaa = `@${hj.split`@`[0]}`
       
let mentionedJid = [m.sender]
let scnya = `⟥⟞⟚━┈┈ ❨ Hʏ ${nnn} ❩ ┈┈━⟚⟝⟤`
let footerny = `Rᴇᴄᴏᴅᴇ Bʏ : ${nameown}
Wᴀ Owɴᴇʀ : ${nameown}
Sᴄ Oʀɪ : wa.me/${mek}
Mʏ Pʀᴏᴊᴇᴄᴛ : terbaru

⫹❰⫺ Bɪɢ Tʜᴀɴᴋs Tᴏ ⫹❱⫺
⭝ Tuhan Yang Maha Esa
⭝ Oʀᴀɴɢ Tᴜᴀ
`
conn.sendMessage(m.chat, {
text: scnya + '\n\n' + footerny,
mentions: [m.sender],
contextInfo: {
mentionedJid: [m.sender],
externalAdReply: {
title: v,
thumbnailUrl: zykomd,
sourceUrl: sgc,
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['tqto']
handler.tags = ['main','info']
handler.command = /^(credits|credit|thanks|thanksto|tqto)$/i
module.exports = handler
