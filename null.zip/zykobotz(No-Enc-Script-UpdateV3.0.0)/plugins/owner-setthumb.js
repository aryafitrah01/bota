const fs = require('fs');
const uploadImage = require ('../lib/uploadImage.js');

let handler = async (m, { conn, text, usedPrefix, command }) => {
  let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender;
  let name = await conn.getName(who);
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || '';  
  if (!mime.startsWith('image/')) throw `Kirim/Reply Gambar dengan caption ${usedPrefix + command}\n\nfitur ini adalah ubah gambar thumbnail.jpg atau gambar untuk di bot WhatsApp\n\nby: zyko`;
  m.reply('Tunggu Sebentar...');
  let media = await q.download();  
  // Menyimpan thumbnail bot
  let path = './thumbnail.jpg';
  fs.writeFileSync(path, media);  
  m.reply('Berhasil mengubah thumbnail bot');
};
handler.help = ['setthumb']
handler.tags = ['owner'];
handler.command = /^setthumb|ubahthumbnail$/i;
handler.owner = true;
module.exports = handler;