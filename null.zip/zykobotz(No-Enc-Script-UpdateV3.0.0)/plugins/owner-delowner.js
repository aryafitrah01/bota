/*


Di Record : Zyko MD
©Zyko MD 2024

 * ig: @zzyko_04
 * yt: @zykobotz
 * tt: @zzyko_04

Jangan di hapus creatornya kack
Saya capek ngetik kode 

"Wahai orang-orang yang beriman, mengapakah kamu mengatakan sesuatu yang tidak kamu kerjakan?
Amat besar kebencian di sisi Allah bahwa kamu mengatakan apa-apa yang tidak kamu kerjakan."
(QS ash-Shaff: 2-3).
*/





let handler = async (m, { conn, text }) => {
	let who = text ? (text.replace(/[@ .+-]/g, '') + '@s.whatsapp.net') : m.quoted ? m.quoted.sender : (m.mentionedJid && m.mentionedJid[0]) ? m.mentionedJid[0] : ''
	if (!who) throw `tag atau ketik nomornya!`
	who = who.split('@')[0]
	let owner = global.owner
	if (!global.owner.map(([number]) => number).map(v => v).includes(who)) return m.reply(`[ ! ] User tidak ada dalam list owner.`)
	global.owner = owner.filter(([v]) => !v.includes(who))
	await conn.reply(m.chat, `Menghapus @${who} dari list *owner*.`, m, { mentions: [who + '@s.whatsapp.net'] })
}
handler.help = ['delowner'].map(v => v + ' <@tag>')
handler.tags = ['owner']
handler.command = /^(del|hapus|\-)owner$/i
handler.owner = true
module.exports = handler