let path = require('path');

let handler = async (m, { usedPrefix, command, text }) => {
    switch (command) {
        case 'getplugin':
        case 'gp':
            {
                let ar = Object.keys(plugins);
                let ar1 = ar.map(v => v.replace('.js', ''));
                if (!text) return m.reply(`*LIST GP*\n\n• *gp* : Mengambil script dalam plugin/luar plugin\n• *gp2* : Mengambil script dalam folder\n\nContoh:\n• ${usedPrefix}gp creator\n• ${usedPrefix}gp config\n• ${usedPrefix}gp lib/database/json/loli.json\n\n BY : zeyybotz`);
                if (!ar1.includes(text)) {
                    let pluginPath = path.join(__dirname, '..', text + '.js');
                    try {
                        m.reply(require('fs').readFileSync(pluginPath, 'utf-8'));
                    } catch (e) {
                        throw `'${text}' tidak ditemukan!\n\n${ar1.map(v => ' ' + v).join`\n`}`;
                    }
                } else {
                    m.reply(require('fs').readFileSync('./plugins/' + text + '.js', 'utf-8'));
                }
            }
            break;
        case 'getplugin2':
        case 'gp2':
            {
                let ar = Object.keys(plugins);
                let ar1 = ar.map(v => v.replace('.js', ''));

                if (!text) throw `uhm.. teksnya mana?\n\ncontoh:\n${usedPrefix + command} menu dalam plugis\n\n luar plugis gp email/database/json/owner-json sesuai folder`;
                let pluginPath;
                if (text.includes("/")) {
                    pluginPath = path.join(__dirname, '..', text);
                } else {
                    pluginPath = path.join(__dirname, '..', 'plugins', text + '.js');
                }

                try {
                    m.reply(require('fs').readFileSync(pluginPath, 'utf-8'));
                } catch (e) {
                    throw `'${text}' tidak ditemukan!\n\n${ar1.map(v => ' ' + v).join`\n`}`;
                }
            }
            break;
    }
}

handler.help = ['getplugin', 'gp', 'getplugin2', 'gp2'].map(v => v + ' <teks>');
handler.command = /^(getplugin|gp|getplugin2|gp2)$/i;
handler.owner = true;

module.exports = handler;
