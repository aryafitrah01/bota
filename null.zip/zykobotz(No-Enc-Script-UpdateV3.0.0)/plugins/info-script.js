const { pickRandom } = require("../lib/function")
const fs = require('fs')
let handler = async(m, { conn, text, usedPrefix, command }) => {
	let fdoc = {
  key : {
  remoteJid: 'status@broadcast',
  participant : '0@s.whatsapp.net'
  },
  message: {
  documentMessage: {
  title: `s c r i p t b o t w h a t s a p p`, 
  jpegThumbnail: fs.readFileSync('./thumbnail.jpg'),
                            }
                          }
                        }
let name = await conn.getName(m.sender)
let imgr = pickRandom(flaaa)
let sc = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=Script By zeyybotz'
let str = `

_Hello @${m.sender.split("@")[0]} 👋_


*_Cari Sc Ya ?_*
*_Cari aja diyt banyak kok`
conn.sendMessage(
  m.chat,
  {
    image: { url: sc },
    caption: str,
    mentions: [m.sender]
  },
  { quoted: fdoc }
);

/*conn.sendMessage(m.chat, {
text: str,
mentions: [m.sender],
contextInfo: {
mentionedJid: [m.sender],
externalAdReply: {
title: v,
thumbnailUrl: sc,
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: fkontak}) */
}
handler.help = ['source code']
handler.tags = ['info']
handler.command =  /^(script|sc)$/i

module.exports = handler
